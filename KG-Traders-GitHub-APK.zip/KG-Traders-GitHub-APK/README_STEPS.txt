KG TRADERS - GitHub eken APK ekak hadana widiha
================================================
1. GitHub -> New repository (Private)  ->  Create
2. Add file -> Upload files -> KG-Traders-GitHub-APK.zip eka (extract nokara) NATHNAM extract karapu files okkoma upload karanna -> Commit
3. .github/workflows/build-apk.yml  kiyana file eka hadanna (workflow file eka oyama dama ganna one):
     Add file -> Create new file -> nama:  .github/workflows/build-apk.yml  -> build-apk.yml eke text paste karanna -> Commit
     (nathnam build-apk.yml upload karala, edit (pencil) karala nama eka  .github/workflows/build-apk.yml  karanna)
4. Actions tab -> build eka run wenawa (minute 5-8). Green unama:
     Repository -> Releases -> latest -> KG-Traders-v3.2-release.apk -> download -> install
   Red unoth: "Build the APK" step eka open karala, uda annotation eke error text eka evanna.

Aluth wenas kamak: index.html replace karanna (nathnam aluth zip ekak upload karanna) -> APK eka auto ayeth hadenawa.
kgtraders.keystore ekama sign karanna use karanawa - nathi nokara thiyaganna. Repo eka Private karanna.
